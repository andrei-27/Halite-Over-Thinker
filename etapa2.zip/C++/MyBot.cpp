#include <bits/stdc++.h>
#include <fstream>
#include <vector>

#include "hlt.hpp"
#include "networking.hpp"

#define MAX_STRENGTH 255
#define BOT_NAME "HOT"

#define ALPHA 0.1
#define ENEMY_ROI -0.5
#define EXPLORATION_DELAY 5
#define ATTACK_DELAY 7
#define INF 1e9

using std::set;
using std::map;
using std::vector;
using std::pair;

static int turn = -1;
static double DELTA_DEGRADATION = 0.2;
static int delay = EXPLORATION_DELAY;
static unsigned char myID;

static set<hlt::Move> moves;
static std::map<pair<unsigned char, unsigned char>, double> pf_map;
std::vector<std::vector<int>> strengths(100, std::vector<int>(100, 0));

inline double degrade_potential(double potential, int distance) {
    return potential + DELTA_DEGRADATION * pow(distance, 2);
}

unsigned char opposite(unsigned char direction) {
    if (direction == NORTH) return SOUTH;
    if (direction == EAST) return WEST;
    if (direction == SOUTH) return NORTH;
    if (direction == WEST) return EAST;
    return STILL;
}

bool checkStrength(hlt::GameMap map, hlt::Location loc, unsigned char direction) {
    hlt::Site site = map.getSite(loc);
    hlt::Site neighbor = map.getSite(loc, direction);
    hlt::Location neigh_loc = map.getLocation(loc, direction);
    unsigned char myID = site.owner;

    if (neighbor.owner == myID) {
        if (site.strength + strengths[neigh_loc.y][neigh_loc.x] + neighbor.strength + neighbor.production > MAX_STRENGTH * 1.4) {
            return false;
        }
    } else {
        if (site.strength + strengths[neigh_loc.y][neigh_loc.x] - neighbor.strength > MAX_STRENGTH * 1.2) {
            return false;
        }
    }

    strengths[neigh_loc.y][neigh_loc.x] += site.strength;
    return true;
}

hlt::Move assign_move(hlt::GameMap &game_map, hlt::Location loc,
                        map<pair<unsigned short, unsigned short>, int> &destinations,
                        map<pair<unsigned short, unsigned short>,
                            vector<pair<hlt::Location, unsigned char>>> &origins) {
    hlt::Site &site = game_map.getSite(loc);
    double potential = INF;
    unsigned char best_d = STILL;
    hlt::Location target;
    

    bool staying_is_bad = site.strength + site.production + destinations[{loc.x, loc.y}] > MAX_STRENGTH;

    for (const int d : CARDINALS) {
        hlt::Location neighbor = game_map.getLocation(loc, d);
        if (destinations.find({neighbor.x, neighbor.y}) != destinations.end()) {
            destinations[{neighbor.x, neighbor.y}] = 0;
        }
        if (destinations[{neighbor.x, neighbor.y}] + site.strength > MAX_STRENGTH) {
            continue;
        }

        if (pf_map[{neighbor.x, neighbor.y}] <= potential) {
            potential = pf_map[{neighbor.x, neighbor.y}];
            best_d = d;
            target = neighbor;
        }

        if (game_map.getSite(neighbor).owner != myID || game_map.getSite(neighbor).owner != 0) {
            delay = ATTACK_DELAY;
        }
    }

    hlt::Site &target_site = game_map.getSite(target);
    if (potential > INF / 10) {
        if (staying_is_bad) {
            best_d = STILL;

            for (const int d : CARDINALS) {
                hlt::Location neighbor = game_map.getLocation(loc, d);
 
                int neigh_potential = site.strength + destinations[{neighbor.x, neighbor.y}];
                if (neigh_potential < potential) {
                    potential = neigh_potential;
                    best_d = d;
                }
            }
            if (checkStrength(game_map, loc, best_d)) {
                return {loc, best_d};
            }
        }
        if (checkStrength(game_map, loc, STILL)) {
            return {loc, STILL};
        }
    }

    if (!staying_is_bad) {
        for (const int d : CARDINALS) {
            hlt::Location neighbor = game_map.getLocation(loc, d);
            if (moves.find({neighbor, best_d}) != moves.end()) {
                if (checkStrength(game_map, loc, STILL)) {
                    return {loc, STILL};
                }
            }
        }

        if (destinations[{loc.x, loc.y}] > 0) {
            if (checkStrength(game_map, loc, STILL)) {
                return {loc, STILL};
            }
        }
    }

    if (staying_is_bad) {
        hlt::Location best_loc = loc;
        for (const auto &origin : origins[{target.x, target.y}]) {
            if (origin.first.x == loc.x && origin.first.y == loc.y) {
                return {loc, origin.second};
            }
            if (destinations[{origin.first.x, origin.first.y}] + site.strength <= MAX_STRENGTH) {
                best_loc = origin.first;
            }
        }
        if (checkStrength(game_map, loc, best_d)) {
            return {loc, best_d};
        }
    }
    

    if (target_site.owner != myID) {
        if (site.strength == MAX_STRENGTH || site.strength > target_site.strength) {
            if (checkStrength(game_map, loc, best_d)) {
                return {loc, best_d};
            }
        }
        if (checkStrength(game_map, loc, STILL)) {
            return {loc, STILL};
        }
    }

    if (site.strength >= site.production * delay) {
        if (checkStrength(game_map, loc, best_d)) {
            return {loc, best_d};
        }
    }
    if (checkStrength(game_map, loc, STILL)) {
        return {loc, STILL};
    }
    for (const int d : CARDINALS) {
        hlt::Location neighbor = game_map.getLocation(loc, d);
        if (checkStrength(game_map, loc, d)) {
            return {loc, static_cast<unsigned char>(d)};
        }
    }
    return {loc, STILL};
}

double initial_potential(hlt::GameMap &game_map, hlt::Location loc) {
    const hlt::Site site = game_map.getSite(loc);
    if (site.owner == 0 && site.strength == 0) {
        int cnt = 0;
        for (const int d : CARDINALS) {
            hlt::Site &neigh = game_map.getSite(loc, d);
            if (neigh.owner != 0 && neigh.owner != myID) {
                cnt++;
            }
        }
        return ENEMY_ROI * cnt;
    } else if (site.production == 0) {
        return INF;
    } else {
        return static_cast<double>(site.strength) / site.production;
    }
}

void initial_check(hlt::GameMap &game_map, unsigned char myID) {
    set<unsigned char> players;
    for (unsigned short x = 0; x < game_map.width; ++x) {
        for (unsigned short y = 0; y < game_map.height; ++y) {
            players.insert(game_map.getSite({x, y}).owner);
        }
    }
    if (game_map.width <= 25 || game_map.height <= 25) {
        DELTA_DEGRADATION = 0.4;
        delay = 6;
    }
}

int main() {
    hlt::GameMap game_map;
    getInit(myID, game_map);
    sendInit(BOT_NAME);

    while(true) {
        moves.clear();
        turn++;
        getFrame(game_map);

        if (turn == 0) {
            initial_check(game_map, myID);
        }

        for (unsigned short x = 0; x < game_map.width; ++x) {
            for (unsigned short y = 0; y < game_map.height; ++y) {
                strengths[y][x] = 0;
            }
        }

        auto comp = [](const std::tuple<double, double, int, hlt::Location>& a, const std::tuple<double, double, int, hlt::Location>& b) {
            return std::get<0>(a) > std::get<0>(b);
        };
        std::priority_queue<std::tuple<double, double, int, hlt::Location>,
                            std::vector<std::tuple<double, double, int, hlt::Location>>,
                            decltype(comp)> heap(comp);
        for (unsigned short x = 0; x < game_map.width; ++x) {
            for (unsigned short y = 0; y < game_map.height; ++y) {
                const hlt::Location loc = {x, y};
                const hlt::Site site = game_map.getSite(loc);
                if (site.owner == myID) {
                    continue;
                }
                const double potential = initial_potential(game_map, loc);
                heap.push({potential, potential, 0, loc});
            }
        }


        pf_map.clear();
        while (pf_map.size() < game_map.width * game_map.height) {
            auto top = heap.top();
            double potential = std::get<1>(top);
            int friendly_distance = std::get<2>(top);
            hlt::Location loc = std::get<3>(top);
            heap.pop();

            auto search = pf_map.find({loc.x, loc.y});
            if (search != pf_map.end()) {
                continue;
            }

            pf_map[{loc.x, loc.y}] = degrade_potential(potential, friendly_distance);
            for (const int d : CARDINALS) {
                hlt::Location neigh_loc = game_map.getLocation(loc, d);
                double neigh_potential = INF;

                const hlt::Site &neigh = game_map.getSite(loc, d);
                if (neigh.owner != myID) {
                    if (neigh.production && !neigh.owner) {
                        neigh_potential = (1 - ALPHA) * potential + ALPHA * (static_cast<double>(neigh.strength) / neigh.production);
                    }
                    heap.push({neigh_potential, neigh_potential, friendly_distance, neigh_loc});
                } else {
                    neigh_potential = degrade_potential(potential, friendly_distance + 1);
                    heap.push({neigh_potential, potential, friendly_distance + 1, neigh_loc});
                }
            }
        }

        map<pair<unsigned short, unsigned short>, int> destinations;
        map<pair<unsigned short, unsigned short>,
            vector<pair<hlt::Location, unsigned char>>> origins;

        vector<pair<pair<unsigned short, unsigned short>, int>> squares;
        for (unsigned short x = 0; x < game_map.width; ++x) {
            for (unsigned short y = 0; y < game_map.height; ++y) {
                const hlt::Location loc = {x, y};
                const hlt::Site site = game_map.getSite(loc);
                if (site.owner == myID && site.strength > 0) {
                    squares.push_back({{x, y}, site.strength});
                }
            }
        }

        sort(squares.begin(), squares.end(), [](
         pair<pair<unsigned short, unsigned short>, int> &a,
         pair<pair<unsigned short, unsigned short>, int> &b) {
            return a.second < b.second;
        });

        for (const auto &square : squares) {
            hlt::Move move = assign_move(game_map, {square.first.first, square.first.second}, destinations, origins);
            moves.insert(move);

            hlt::Location target = game_map.getLocation({square.first.first, square.first.second}, move.dir);

            destinations[{target.x, target.y}] += square.second;

            origins[{target.x, target.y}].push_back({{square.first.first, square.first.second}, opposite(move.dir)});
        }

        sendFrame(moves);
    }

    return 0;
}
